public class Rice extends Item {

    public Rice(String name, int calories, int price) {
        super(name, calories, price);
        //TODO Auto-generated constructor stub
    }
    
}
