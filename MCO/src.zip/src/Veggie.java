public class Veggie extends Item {

    public Veggie(String name, int calories, int price) {
        super(name, calories, price);
        //TODO Auto-generated constructor stub
    }
    
}
