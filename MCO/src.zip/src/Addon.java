public class Addon extends Item {

    public Addon(String name, int calories, int price) {
        super(name, calories, price);
        //TODO Auto-generated constructor stub
    }

}